package com.example.data

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.example.R
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class LocalVaultEngine private constructor(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("my_family_vault_prefs", Context.MODE_PRIVATE)

    // Flows for Reactive UI Updates
    private val _currentUser = MutableStateFlow<FamilyUser?>(null)
    val currentUser: StateFlow<FamilyUser?> = _currentUser.asStateFlow()

    private val _users = MutableStateFlow<List<FamilyUser>>(emptyList())
    val users: StateFlow<List<FamilyUser>> = _users.asStateFlow()

    private val _mediaItems = MutableStateFlow<List<MediaItem>>(emptyList())
    val mediaItems: StateFlow<List<MediaItem>> = _mediaItems.asStateFlow()

    private val _moments = MutableStateFlow<List<Moment>>(emptyList())
    val moments: StateFlow<List<Moment>> = _moments.asStateFlow()

    private val _invitations = MutableStateFlow<List<QRInvitation>>(emptyList())
    val invitations: StateFlow<List<QRInvitation>> = _invitations.asStateFlow()

    private val _familyConfig = MutableStateFlow(FamilyConfig())
    val familyConfig: StateFlow<FamilyConfig> = _familyConfig.asStateFlow()

    private val _notifications = MutableStateFlow<List<AppNotification>>(emptyList())
    val notifications: StateFlow<List<AppNotification>> = _notifications.asStateFlow()

    init {
        loadData()
        if (_users.value.isEmpty()) {
            setupInitialWarmData()
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: LocalVaultEngine? = null

        fun getInstance(context: Context): LocalVaultEngine {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: LocalVaultEngine(context.applicationContext).also { INSTANCE = it }
            }
        }
    }

    private fun setupInitialWarmData() {
        val ownerId = "owner_dad"
        val owner = FamilyUser(
            id = ownerId,
            name = "Dad (Owner)",
            role = FamilyRole.OWNER,
            profilePhotoUri = "android.resource://com.example/drawable/ic_launcher_background", // Fallback profile photo
            deviceId = "device_owner_1",
            deviceStatus = DeviceStatus.ACTIVE,
            phoneNumber = "+1 (555) 019-2831",
            defaultUploadQuality = UploadQuality.ORIGINAL_QUALITY
        )

        val adminMom = FamilyUser(
            id = "admin_mom",
            name = "Mom (Admin)",
            role = FamilyRole.ADMIN,
            profilePhotoUri = null,
            deviceId = "device_mom_1",
            deviceStatus = DeviceStatus.ACTIVE,
            phoneNumber = "+1 (555) 014-9932"
        )

        val memberSister = FamilyUser(
            id = "member_sister",
            name = "Sarah (Sister)",
            role = FamilyRole.MEMBER,
            profilePhotoUri = null,
            deviceId = "device_sister_1",
            deviceStatus = DeviceStatus.ACTIVE
        )

        val memberBrother = FamilyUser(
            id = "member_brother",
            name = "Alex (Brother)",
            role = FamilyRole.MEMBER,
            profilePhotoUri = null,
            deviceId = "device_brother_1",
            deviceStatus = DeviceStatus.ACTIVE
        )

        val initialUsers = listOf(owner, adminMom, memberSister, memberBrother)
        _users.value = initialUsers
        _currentUser.value = owner // Default to Owner for initial state

        // Standard Warm Media Items
        val items = listOf(
            MediaItem(
                id = "media_1",
                uriString = "https://images.unsplash.com/photo-1543269865-cbf427effbad?q=80&w=600&auto=format&fit=crop",
                isVideo = false,
                timestamp = System.currentTimeMillis() - 7200000,
                uploaderId = "owner_dad",
                uploaderName = "Dad (Owner)",
                latitude = 37.7749,
                longitude = -122.4194,
                locationName = "San Francisco Golden Gate Park",
                uploadQuality = UploadQuality.ORIGINAL_QUALITY
            ),
            MediaItem(
                id = "media_2",
                uriString = "https://images.unsplash.com/photo-1473186578172-c141e6798cf4?q=80&w=600&auto=format&fit=crop",
                isVideo = false,
                timestamp = System.currentTimeMillis() - 86400000,
                uploaderId = "admin_mom",
                uploaderName = "Mom (Admin)",
                latitude = null,
                longitude = null,
                locationName = null,
                uploadQuality = UploadQuality.SMART_COMPRESSED
            ),
            MediaItem(
                id = "media_3",
                uriString = "https://www.w3schools.com/html/mov_bbb.mp4", // Test video stream
                isVideo = true,
                timestamp = System.currentTimeMillis() - 172800000,
                uploaderId = "member_sister",
                uploaderName = "Sarah (Sister)",
                latitude = 34.0522,
                longitude = -118.2437,
                locationName = "Los Angeles Beach Walk",
                uploadQuality = UploadQuality.SMART_COMPRESSED
            )
        )
        _mediaItems.value = items

        // Warm Moments
        val initialMoments = listOf(
            Moment(
                id = "moment_1",
                text = "We just planned our winter ski trip! Max 10 spots for the cabins. Dad is going to book tomorrow! 🎿🌲",
                timestamp = System.currentTimeMillis() - 3600000,
                uploaderId = "admin_mom",
                uploaderName = "Mom (Admin)"
            ),
            Moment(
                id = "moment_2",
                text = "Congratulations to Sarah for winning the science fair! The volcano actually exploded this time!🌋🏆",
                timestamp = System.currentTimeMillis() - 50000000,
                uploaderId = "owner_dad",
                uploaderName = "Dad (Owner)"
            )
        )
        _moments.value = initialMoments

        _notifications.value = listOf(
            AppNotification(
                id = "notif_1",
                title = "Welcome back Dad!",
                message = "The private family vault is synced and secure. Max 10 member cap enforced.",
                timestamp = System.currentTimeMillis(),
                isRead = false
            ),
            AppNotification(
                id = "notif_2",
                title = "Media Upload Approved",
                message = "Sister uploaded a 5-sec video using 'Smart Compressed' default.",
                timestamp = System.currentTimeMillis() - 172800000,
                isRead = true
            )
        )

        saveData()
    }

    // --- Authentication Actions ---

    fun loginAsUser(user: FamilyUser) {
        _currentUser.value = user
        prefs.edit().putString("active_user_id", user.id).apply()
        addNotification("Logged In", "You logged into your profile as ${user.name}.")
    }

    fun logout() {
        _currentUser.value = null
        prefs.edit().remove("active_user_id").apply()
    }

    fun updateProfile(name: String, profilePhotoUri: String?, phoneNumber: String?) {
        val current = _currentUser.value ?: return
        val updatedUser = current.copy(
            name = name,
            profilePhotoUri = profilePhotoUri,
            phoneNumber = phoneNumber
        )
        _currentUser.value = updatedUser

        // Update in users list
        _users.value = _users.value.map { if (it.id == current.id) updatedUser else it }
        saveData()
        addNotification("Profile Updated", "Your profile details have been saved successfully.")
    }

    fun updateUploadQualityDefault(quality: UploadQuality) {
        val current = _currentUser.value ?: return
        val updatedUser = current.copy(defaultUploadQuality = quality)
        _currentUser.value = updatedUser
        _users.value = _users.value.map { if (it.id == current.id) updatedUser else it }
        saveData()
    }

    // --- QR System & Invite Actions ---

    fun generateQRInvitation(role: FamilyRole): String {
        val activeUser = _currentUser.value
        if (activeUser == null || (activeUser.role != FamilyRole.OWNER && activeUser.role != FamilyRole.ADMIN)) {
            throw SecurityException("Only the Family Owner or Admins can generate QR invitations.")
        }

        val inviteId = "inv_" + UUID.randomUUID().toString().take(8)
        val invitation = QRInvitation(
            id = inviteId,
            role = role,
            generatedBy = activeUser.id,
            timestamp = System.currentTimeMillis()
        )

        _invitations.value = _invitations.value + invitation
        saveData()
        addNotification("QR Generated", "A new invitation code for role: ${role.name} has been generated.")
        
        // This serialized JSON or URI represents the QR code contents
        return "myfamily://enroll?id=$inviteId&role=${role.name}"
    }

    fun claimQRInvitation(inviteId: String, newMemberName: String, newDeviceId: String): Boolean {
        if (_users.value.size >= 10) {
            addNotification("Enrollment Failed", "Failed to add member. Family size is capped at 10.")
            return false
        }

        val invite = _invitations.value.find { it.id == inviteId && !it.isRevoked && it.usedBy == null } ?: return false

        // Mark QR as claimed
        val claimedInvite = invite.copy(usedBy = newMemberName)
        _invitations.value = _invitations.value.map { if (it.id == inviteId) claimedInvite else it }

        // Create new user
        val newUserId = "user_" + UUID.randomUUID().toString().take(8)
        val newUser = FamilyUser(
            id = newUserId,
            name = newMemberName,
            role = invite.role,
            deviceId = newDeviceId,
            deviceStatus = DeviceStatus.ACTIVE
        )

        _users.value = _users.value + newUser
        saveData()

        addNotification("New Member", "Welcome ${newMemberName}! Joined family vault as ${invite.role.name}.")
        return true
    }

    fun revokeDeviceEnrollment(userId: String) {
        val activeUser = _currentUser.value
        if (activeUser == null || (activeUser.role != FamilyRole.OWNER && activeUser.role != FamilyRole.ADMIN)) {
            throw SecurityException("Only Owner or Admin can revoke device enrollments.")
        }

        _users.value = _users.value.map {
            if (it.id == userId) {
                it.copy(deviceStatus = DeviceStatus.REVOKED)
            } else {
                it
            }
        }

        // If the current user's session was revoked, log out immediately
        val current = _currentUser.value
        if (current != null && current.id == userId) {
            logout()
        }

        saveData()
        addNotification("Device Revoked", "Enrollment revoked successfully. Device is blocked from accessing the vault.")
    }

    fun changeMemberRole(userId: String, newRole: FamilyRole) {
        val activeUser = _currentUser.value
        if (activeUser == null || activeUser.role != FamilyRole.OWNER) {
            throw SecurityException("Only the Owner can manage member roles or promote to Admins.")
        }

        _users.value = _users.value.map {
            if (it.id == userId) {
                it.copy(role = newRole)
            } else {
                it
            }
        }
        saveData()
        addNotification("Role Updated", "Member's security role was changed to ${newRole.name}.")
    }

    fun removeMember(userId: String) {
        val activeUser = _currentUser.value
        if (activeUser == null || (activeUser.role != FamilyRole.OWNER && activeUser.role != FamilyRole.ADMIN)) {
            throw SecurityException("Only Owner or Admin can remove family members.")
        }

        val targetUser = _users.value.find { it.id == userId } ?: return
        if (targetUser.role == FamilyRole.OWNER) {
            throw IllegalArgumentException("The Family Owner cannot be removed.")
        }

        _users.value = _users.value.filter { it.id != userId }
        saveData()
        addNotification("Member Removed", "${targetUser.name} has been removed from the family vault.")
    }

    // --- Media & Content Actions ---

    fun uploadMedia(uriString: String, isVideo: Boolean, lat: Double?, lon: Double?, locName: String?, quality: UploadQuality) {
        val uploader = _currentUser.value ?: return
        val newItem = MediaItem(
            id = "media_" + UUID.randomUUID().toString().take(8),
            uriString = uriString,
            isVideo = isVideo,
            timestamp = System.currentTimeMillis(),
            uploaderId = uploader.id,
            uploaderName = uploader.name,
            latitude = lat,
            longitude = lon,
            locationName = locName,
            uploadQuality = quality
        )

        _mediaItems.value = listOf(newItem) + _mediaItems.value
        saveData()
        addNotification("New Upload", "${uploader.name} added a new ${if (isVideo) "video" else "photo"}.")
    }

    fun deleteMedia(mediaId: String) {
        val activeUser = _currentUser.value ?: return
        val item = _mediaItems.value.find { it.id == mediaId } ?: return

        // Permissions: Owner/Admin can delete anything. Members can only delete their OWN.
        val canDelete = activeUser.role == FamilyRole.OWNER || 
                        activeUser.role == FamilyRole.ADMIN || 
                        item.uploaderId == activeUser.id

        if (!canDelete) {
            throw SecurityException("You do not have permission to delete this content.")
        }

        _mediaItems.value = _mediaItems.value.filter { it.id != mediaId }
        saveData()
        addNotification("Media Deleted", "Media content was deleted from the secure timeline.")
    }

    fun addMoment(text: String) {
        val uploader = _currentUser.value ?: return
        val newMoment = Moment(
            id = "moment_" + UUID.randomUUID().toString().take(8),
            text = text,
            timestamp = System.currentTimeMillis(),
            uploaderId = uploader.id,
            uploaderName = uploader.name
        )

        _moments.value = listOf(newMoment) + _moments.value
        saveData()
        addNotification("Moment Shared", "${uploader.name} shared a moment.")
    }

    fun deleteMoment(momentId: String) {
        val activeUser = _currentUser.value ?: return
        val moment = _moments.value.find { it.id == momentId } ?: return

        val canDelete = activeUser.role == FamilyRole.OWNER || 
                        activeUser.role == FamilyRole.ADMIN || 
                        moment.uploaderId == activeUser.id

        if (!canDelete) {
            throw SecurityException("You do not have permission to delete this moment.")
        }

        _moments.value = _moments.value.filter { it.id != momentId }
        saveData()
    }

    // --- Cover Photo ---

    fun updateCoverPhoto(uriString: String?) {
        val activeUser = _currentUser.value
        if (activeUser == null || activeUser.role != FamilyRole.OWNER) {
            throw SecurityException("Only the Family Owner can change or remove the Family Cover Photo.")
        }

        _familyConfig.value = _familyConfig.value.copy(coverPhotoUri = uriString)
        saveData()
        addNotification("Cover Photo Updated", "Family Cover Photo has been modified by the Owner.")
    }

    fun updateFamilyName(name: String) {
        val activeUser = _currentUser.value
        if (activeUser == null || (activeUser.role != FamilyRole.OWNER && activeUser.role != FamilyRole.ADMIN)) {
            throw SecurityException("Only Owner or Admins can update the family vault name.")
        }

        _familyConfig.value = _familyConfig.value.copy(familyName = name)
        saveData()
        addNotification("Vault Renamed", "Family vault renamed to: $name.")
    }

    // --- Helper Functions ---

    fun addNotification(title: String, message: String) {
        val notif = AppNotification(
            id = "notif_" + UUID.randomUUID().toString().take(8),
            title = title,
            message = message,
            timestamp = System.currentTimeMillis()
        )
        _notifications.value = listOf(notif) + _notifications.value
        saveData()
    }

    fun markNotificationsAsRead() {
        _notifications.value = _notifications.value.map { it.copy(isRead = true) }
        saveData()
    }

    // --- JSON Serialization Persistence ---

    private fun saveData() {
        try {
            val editor = prefs.edit()

            // Save Users
            val usersArray = JSONArray()
            _users.value.forEach { u ->
                val obj = JSONObject()
                obj.put("id", u.id)
                obj.put("name", u.name)
                obj.put("role", u.role.name)
                obj.put("profilePhotoUri", u.profilePhotoUri ?: "")
                obj.put("deviceId", u.deviceId ?: "")
                obj.put("deviceStatus", u.deviceStatus.name)
                obj.put("phoneNumber", u.phoneNumber ?: "")
                obj.put("defaultUploadQuality", u.defaultUploadQuality.name)
                usersArray.put(obj)
            }
            editor.putString("users_list", usersArray.toString())

            // Save Current User ID
            editor.putString("active_user_id", _currentUser.value?.id ?: "")

            // Save Media Items
            val mediaArray = JSONArray()
            _mediaItems.value.forEach { m ->
                val obj = JSONObject()
                obj.put("id", m.id)
                obj.put("uriString", m.uriString)
                obj.put("isVideo", m.isVideo)
                obj.put("timestamp", m.timestamp)
                obj.put("uploaderId", m.uploaderId)
                obj.put("uploaderName", m.uploaderName)
                obj.put("latitude", m.latitude ?: -999.0)
                obj.put("longitude", m.longitude ?: -999.0)
                obj.put("locationName", m.locationName ?: "")
                obj.put("uploadQuality", m.uploadQuality.name)
                mediaArray.put(obj)
            }
            editor.putString("media_list", mediaArray.toString())

            // Save Moments
            val momentsArray = JSONArray()
            _moments.value.forEach { mo ->
                val obj = JSONObject()
                obj.put("id", mo.id)
                obj.put("text", mo.text)
                obj.put("timestamp", mo.timestamp)
                obj.put("uploaderId", mo.uploaderId)
                obj.put("uploaderName", mo.uploaderName)
                momentsArray.put(obj)
            }
            editor.putString("moments_list", momentsArray.toString())

            // Save Config
            val configObj = JSONObject()
            configObj.put("familyName", _familyConfig.value.familyName)
            configObj.put("coverPhotoUri", _familyConfig.value.coverPhotoUri ?: "")
            editor.putString("family_config", configObj.toString())

            // Save Notifications
            val notifsArray = JSONArray()
            _notifications.value.forEach { n ->
                val obj = JSONObject()
                obj.put("id", n.id)
                obj.put("title", n.title)
                obj.put("message", n.message)
                obj.put("timestamp", n.timestamp)
                obj.put("isRead", n.isRead)
                notifsArray.put(obj)
            }
            editor.putString("notifications_list", notifsArray.toString())

            editor.apply()
        } catch (e: Exception) {
            Log.e("LocalVaultEngine", "Error saving vault data", e)
        }
    }

    private fun loadData() {
        try {
            val usersStr = prefs.getString("users_list", null)
            if (usersStr != null) {
                val array = JSONArray(usersStr)
                val list = mutableListOf<FamilyUser>()
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val photo = obj.optString("profilePhotoUri").let { if (it.isEmpty()) null else it }
                    val device = obj.optString("deviceId").let { if (it.isEmpty()) null else it }
                    val phone = obj.optString("phoneNumber").let { if (it.isEmpty()) null else it }
                    list.add(
                        FamilyUser(
                            id = obj.getString("id"),
                            name = obj.getString("name"),
                            role = FamilyRole.valueOf(obj.getString("role")),
                            profilePhotoUri = photo,
                            deviceId = device,
                            deviceStatus = DeviceStatus.valueOf(obj.getString("deviceStatus")),
                            phoneNumber = phone,
                            defaultUploadQuality = UploadQuality.valueOf(obj.optString("defaultUploadQuality", "ASK"))
                        )
                    )
                }
                _users.value = list
            }

            val activeUserId = prefs.getString("active_user_id", null)
            if (activeUserId != null && activeUserId.isNotEmpty()) {
                _currentUser.value = _users.value.find { it.id == activeUserId }
            }

            val mediaStr = prefs.getString("media_list", null)
            if (mediaStr != null) {
                val array = JSONArray(mediaStr)
                val list = mutableListOf<MediaItem>()
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val lat = obj.getDouble("latitude").let { if (it == -999.0) null else it }
                    val lon = obj.getDouble("longitude").let { if (it == -999.0) null else it }
                    val loc = obj.optString("locationName").let { if (it.isEmpty()) null else it }
                    list.add(
                        MediaItem(
                            id = obj.getString("id"),
                            uriString = obj.getString("uriString"),
                            isVideo = obj.getBoolean("isVideo"),
                            timestamp = obj.getLong("timestamp"),
                            uploaderId = obj.getString("uploaderId"),
                            uploaderName = obj.getString("uploaderName"),
                            latitude = lat,
                            longitude = lon,
                            locationName = loc,
                            uploadQuality = UploadQuality.valueOf(obj.optString("uploadQuality", "SMART_COMPRESSED"))
                        )
                    )
                }
                _mediaItems.value = list
            }

            val momentsStr = prefs.getString("moments_list", null)
            if (momentsStr != null) {
                val array = JSONArray(momentsStr)
                val list = mutableListOf<Moment>()
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    list.add(
                        Moment(
                            id = obj.getString("id"),
                            text = obj.getString("text"),
                            timestamp = obj.getLong("timestamp"),
                            uploaderId = obj.getString("uploaderId"),
                            uploaderName = obj.getString("uploaderName")
                        )
                    )
                }
                _moments.value = list
            }

            val configStr = prefs.getString("family_config", null)
            if (configStr != null) {
                val obj = JSONObject(configStr)
                val cover = obj.optString("coverPhotoUri").let { if (it.isEmpty()) null else it }
                _familyConfig.value = FamilyConfig(
                    familyName = obj.optString("familyName", "Our Family"),
                    coverPhotoUri = cover
                )
            }

            val notificationsStr = prefs.getString("notifications_list", null)
            if (notificationsStr != null) {
                val array = JSONArray(notificationsStr)
                val list = mutableListOf<AppNotification>()
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    list.add(
                        AppNotification(
                            id = obj.getString("id"),
                            title = obj.getString("title"),
                            message = obj.getString("message"),
                            timestamp = obj.getLong("timestamp"),
                            isRead = obj.optBoolean("isRead", false)
                        )
                    )
                }
                _notifications.value = list
            }

        } catch (e: Exception) {
            Log.e("LocalVaultEngine", "Error loading vault data", e)
        }
    }
}
