package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import com.example.data.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FamilyTab(
    vaultEngine: LocalVaultEngine
) {
    val context = LocalContext.current
    val currentUser by vaultEngine.currentUser.collectAsState()
    val users by vaultEngine.users.collectAsState()
    val familyConfig by vaultEngine.familyConfig.collectAsState()

    var showCoverChangeDialog by remember { mutableStateOf(false) }
    var showAddMemberDialog by remember { mutableStateOf(false) }
    var selectedRoleToInvite by remember { mutableStateOf(FamilyRole.MEMBER) }
    var generatedQrLink by remember { mutableStateOf<String?>(null) }

    // Cover Photo Picker Contract
    val coverPhotoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            vaultEngine.updateCoverPhoto(uri.toString())
            Toast.makeText(context, "Cover photo updated!", Toast.LENGTH_SHORT).show()
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surface),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        // Family Cover Photo Banner (Owner can change, Admin/Member view only)
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                if (familyConfig.coverPhotoUri != null) {
                    Image(
                        painter = rememberAsyncImagePainter(familyConfig.coverPhotoUri),
                        contentDescription = "Family Cover Photo",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    // Modern Illustration Fallback
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Landscape,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.5f),
                            modifier = Modifier.size(60.dp)
                        )
                        Text(
                            text = "No Cover Photo Configured",
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.6f),
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }

                // Edit Button: ONLY visible and accessible to the Owner
                if (currentUser?.role == FamilyRole.OWNER) {
                    SmallFloatingActionButton(
                        onClick = { showCoverChangeDialog = true },
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(12.dp),
                        containerColor = MaterialTheme.colorScheme.surface,
                        contentColor = MaterialTheme.colorScheme.primary
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = "Change Cover")
                    }
                }
            }
        }

        // Family Title & Header Metrics
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = familyConfig.familyName,
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    // Capacity indicator: max 10
                    Badge(
                        containerColor = if (users.size >= 10) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.padding(4.dp)
                    ) {
                        Text(
                            text = "${users.size} / 10 Members",
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(6.dp),
                            color = if (users.size >= 10) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }

                Text(
                    text = "A secure, private social ring for close relations. Max 10 member cap strictly enforced for data privacy protection.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                )

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            }
        }

        // Generate Invite QR Panel (Owner/Admin only)
        if (currentUser?.role == FamilyRole.OWNER || currentUser?.role == FamilyRole.ADMIN) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.QrCode,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.secondary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Invite New Member",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }

                        Text(
                            text = "Add up to 10 relatives. Generates a secure enrollment link. Members join instantly, Admins require OTP validation.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.8f),
                            modifier = Modifier.padding(vertical = 8.dp)
                        )

                        if (users.size >= 10) {
                            Text(
                                text = "⚠️ Family vault is full (10 members limit reached). Revoke an existing member to add others.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error,
                                fontWeight = FontWeight.Bold
                            )
                        } else {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Button(
                                    onClick = {
                                        selectedRoleToInvite = FamilyRole.MEMBER
                                        generatedQrLink = vaultEngine.generateQRInvitation(FamilyRole.MEMBER)
                                        showAddMemberDialog = true
                                    },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                ) {
                                    Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Add Member QR", fontSize = 12.sp)
                                }

                                Button(
                                    onClick = {
                                        selectedRoleToInvite = FamilyRole.ADMIN
                                        generatedQrLink = vaultEngine.generateQRInvitation(FamilyRole.ADMIN)
                                        showAddMemberDialog = true
                                    },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                                ) {
                                    Icon(Icons.Default.AdminPanelSettings, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Add Admin QR", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Section Title: Member list
        item {
            Text(
                text = "Active Circle Members",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )
        }

        // Render List of active family users
        items(users, key = { it.id }) { member ->
            MemberRowItem(
                member = member,
                currentUser = currentUser,
                onPromoteToAdmin = {
                    vaultEngine.changeMemberRole(member.id, FamilyRole.ADMIN)
                    Toast.makeText(context, "${member.name} promoted to Admin.", Toast.LENGTH_SHORT).show()
                },
                onDemoteToMember = {
                    vaultEngine.changeMemberRole(member.id, FamilyRole.MEMBER)
                    Toast.makeText(context, "${member.name} demoted to Member.", Toast.LENGTH_SHORT).show()
                },
                onRevokeDevice = {
                    vaultEngine.revokeDeviceEnrollment(member.id)
                    Toast.makeText(context, "Device access revoked for ${member.name}.", Toast.LENGTH_SHORT).show()
                },
                onRemove = {
                    try {
                        vaultEngine.removeMember(member.id)
                        Toast.makeText(context, "Member removed.", Toast.LENGTH_SHORT).show()
                    } catch (e: Exception) {
                        Toast.makeText(context, e.message ?: "Failed.", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }
    }

    // Cover Change Action dialog (Owner only)
    if (showCoverChangeDialog) {
        AlertDialog(
            onDismissRequest = { showCoverChangeDialog = false },
            title = { Text("Family Cover Photo") },
            text = { Text("As the Owner of this family vault, you can update or clear the primary cover photo banner.") },
            confirmButton = {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            showCoverChangeDialog = false
                            coverPhotoLauncher.launch("image/*")
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Select Photo")
                    }

                    if (familyConfig.coverPhotoUri != null) {
                        Button(
                            onClick = {
                                showCoverChangeDialog = false
                                vaultEngine.updateCoverPhoto(null)
                                Toast.makeText(context, "Cover photo cleared.", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                        ) {
                            Text("Clear")
                        }
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showCoverChangeDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Add Member QR Dialog (Invite)
    if (showAddMemberDialog && generatedQrLink != null) {
        AlertDialog(
            onDismissRequest = { showAddMemberDialog = false },
            title = {
                Text(
                    text = if (selectedRoleToInvite == FamilyRole.ADMIN) "New Admin Enrollment QR" else "New Member Enrollment QR",
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = if (selectedRoleToInvite == FamilyRole.ADMIN)
                            "Generates administrative access. Relatives must scan this QR code and complete a secure OTP authentication."
                            else "Normal member. Scan to instantly enroll device without OTP requirements.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    // simulated visual QR representation
                    Box(
                        modifier = Modifier
                            .size(160.dp)
                            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCode2,
                            contentDescription = "Simulated QR Code",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(120.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Claim Code Link:",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        text = generatedQrLink!!,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Center,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 4.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = ClipData.newPlainText("Family QR Code", generatedQrLink)
                            clipboard.setPrimaryClip(clip)
                            Toast.makeText(context, "Code copied! Paste this in the Member QR input on login screen.", Toast.LENGTH_LONG).show()
                        }
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Copy Claim Link")
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAddMemberDialog = false }) {
                    Text("Done")
                }
            }
        )
    }
}

@Composable
fun MemberRowItem(
    member: FamilyUser,
    currentUser: FamilyUser?,
    onPromoteToAdmin: () -> Unit,
    onDemoteToMember: () -> Unit,
    onRevokeDevice: () -> Unit,
    onRemove: () -> Unit
) {
    var expandedMenu by remember { mutableStateOf(false) }

    // Check action authority
    val isOwner = currentUser?.role == FamilyRole.OWNER
    val isAdmin = currentUser?.role == FamilyRole.ADMIN

    // Cannot perform destructive actions on self
    val isSelf = member.id == currentUser?.id

    // Permissions logic
    val canPromoteDemote = isOwner && member.role != FamilyRole.OWNER
    val canRevokeDevice = (isOwner || isAdmin) && !isSelf && member.role != FamilyRole.OWNER
    val canRemove = (isOwner || isAdmin) && !isSelf && member.role != FamilyRole.OWNER

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Profile photo badge
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(
                        if (member.role == FamilyRole.OWNER) MaterialTheme.colorScheme.primaryContainer
                        else if (member.role == FamilyRole.ADMIN) MaterialTheme.colorScheme.secondaryContainer
                        else MaterialTheme.colorScheme.tertiaryContainer
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (member.profilePhotoUri != null) {
                    Image(
                        painter = rememberAsyncImagePainter(member.profilePhotoUri),
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Text(
                        text = member.name.take(1).uppercase(),
                        fontWeight = FontWeight.Bold,
                        color = if (member.role == FamilyRole.OWNER) MaterialTheme.colorScheme.onPrimaryContainer
                        else if (member.role == FamilyRole.ADMIN) MaterialTheme.colorScheme.onSecondaryContainer
                        else MaterialTheme.colorScheme.onTertiaryContainer
                    )
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = member.name,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodyLarge
                    )
                    if (isSelf) {
                        Spacer(modifier = Modifier.width(6.dp))
                        SuggestionChip(
                            onClick = {},
                            label = { Text("You", fontSize = 10.sp) },
                            modifier = Modifier.height(20.dp)
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Role Badge label
                    Text(
                        text = member.role.name,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (member.role == FamilyRole.OWNER) MaterialTheme.colorScheme.primary
                        else if (member.role == FamilyRole.ADMIN) MaterialTheme.colorScheme.secondary
                        else MaterialTheme.colorScheme.outline,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    // Device connection status
                    Text(
                        text = "• ${member.deviceStatus.name}",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (member.deviceStatus == DeviceStatus.ACTIVE) Color(0xFF2E7D32)
                        else MaterialTheme.colorScheme.error,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Options dropdown menu trigger (Owner/Admin permissions only)
            if (canPromoteDemote || canRevokeDevice || canRemove) {
                Box {
                    IconButton(onClick = { expandedMenu = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "Member Actions")
                    }

                    DropdownMenu(
                        expanded = expandedMenu,
                        onDismissRequest = { expandedMenu = false }
                    ) {
                        if (canPromoteDemote) {
                            if (member.role == FamilyRole.MEMBER) {
                                DropdownMenuItem(
                                    text = { Text("Promote to Admin") },
                                    leadingIcon = { Icon(Icons.Default.Security, contentDescription = null) },
                                    onClick = {
                                        expandedMenu = false
                                        onPromoteToAdmin()
                                    }
                                )
                            } else if (member.role == FamilyRole.ADMIN) {
                                DropdownMenuItem(
                                    text = { Text("Demote to Member") },
                                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                                    onClick = {
                                        expandedMenu = false
                                        onDemoteToMember()
                                    }
                                )
                            }
                        }

                        if (canRevokeDevice) {
                            if (member.deviceStatus == DeviceStatus.ACTIVE) {
                                DropdownMenuItem(
                                    text = { Text("Revoke Device Access") },
                                    leadingIcon = { Icon(Icons.Default.PhonelinkErase, contentDescription = null) },
                                    onClick = {
                                        expandedMenu = false
                                        onRevokeDevice()
                                    }
                                )
                            }
                        }

                        if (canRemove) {
                            DropdownMenuItem(
                                text = { Text("Remove from Family", color = MaterialTheme.colorScheme.error) },
                                leadingIcon = { Icon(Icons.Default.PersonRemove, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                                onClick = {
                                    expandedMenu = false
                                    onRemove()
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
