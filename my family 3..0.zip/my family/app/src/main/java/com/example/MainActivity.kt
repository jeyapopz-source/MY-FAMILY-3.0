package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.example.data.LocalVaultEngine
import com.example.data.MediaItem
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.MainHubScreen
import com.example.ui.screens.MediaDetailScreen
import com.example.ui.screens.ProfileSettingsScreen
import com.example.ui.theme.MyApplicationTheme

sealed interface Screen {
    object Login : Screen
    object MainHub : Screen
    object ProfileSettings : Screen
    data class MediaDetail(val item: MediaItem) : Screen
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        val vaultEngine = LocalVaultEngine.getInstance(this)

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    var currentScreen by remember { 
                        mutableStateOf<Screen>(
                            if (vaultEngine.currentUser.value != null) Screen.MainHub else Screen.Login
                        ) 
                    }

                    // Secure session state check (If revoked, kick to login screen instantly)
                    val currentUser by vaultEngine.currentUser.collectAsState()
                    LaunchedEffect(currentUser) {
                        if (currentUser == null) {
                            currentScreen = Screen.Login
                        }
                    }

                    // Handle system back buttons correctly per screen destination
                    BackHandler(enabled = currentScreen != Screen.Login && currentScreen != Screen.MainHub) {
                        currentScreen = when (currentScreen) {
                            Screen.ProfileSettings -> Screen.MainHub
                            is Screen.MediaDetail -> Screen.MainHub
                            else -> Screen.MainHub
                        }
                    }

                    Crossfade(targetState = currentScreen, label = "ScreenTransition") { screen ->
                        when (screen) {
                            is Screen.Login -> {
                                LoginScreen(
                                    vaultEngine = vaultEngine,
                                    onLoginSuccess = {
                                        currentScreen = Screen.MainHub
                                    }
                                )
                            }
                            is Screen.MainHub -> {
                                MainHubScreen(
                                    vaultEngine = vaultEngine,
                                    onNavigateToDetail = { mediaItem ->
                                        currentScreen = Screen.MediaDetail(mediaItem)
                                    },
                                    onNavigateToProfileSettings = {
                                        currentScreen = Screen.ProfileSettings
                                    },
                                    onLogout = {
                                        currentScreen = Screen.Login
                                    }
                                )
                            }
                            is Screen.ProfileSettings -> {
                                ProfileSettingsScreen(
                                    vaultEngine = vaultEngine,
                                    onBack = {
                                        currentScreen = Screen.MainHub
                                    },
                                    onLogout = {
                                        currentScreen = Screen.Login
                                    }
                                )
                            }
                            is Screen.MediaDetail -> {
                                MediaDetailScreen(
                                    mediaItem = screen.item,
                                    vaultEngine = vaultEngine,
                                    onBack = {
                                        currentScreen = Screen.MainHub
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
