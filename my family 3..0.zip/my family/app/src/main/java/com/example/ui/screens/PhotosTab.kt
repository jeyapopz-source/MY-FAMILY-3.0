package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import coil.compose.rememberAsyncImagePainter
import com.example.data.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhotosTab(
    vaultEngine: LocalVaultEngine,
    onNavigateToDetail: (MediaItem) -> Unit
) {
    val context = LocalContext.current
    val mediaItems by vaultEngine.mediaItems.collectAsState()
    val currentUser by vaultEngine.currentUser.collectAsState()

    val photosOnly = remember(mediaItems) { mediaItems.filter { !it.isVideo } }

    var showUploadSourceDialog by remember { mutableStateOf(false) }
    var showQualityPrompt by remember { mutableStateOf(false) }
    var showOverrideQualityDialog by remember { mutableStateOf(false) }
    var pendingPhotoUriStr by remember { mutableStateOf<String?>(null) }
    var isSimulatedChoice by remember { mutableStateOf(false) }

    // Real Gallery Picker Contract
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val uriStr = uri.toString()
            pendingPhotoUriStr = uriStr
            isSimulatedChoice = false
            checkUploadQualityFlow(currentUser, vaultEngine, onPrompt = { showQualityPrompt = true }, onDirectUpload = { quality ->
                uploadPhotoWithGPS(uriStr, quality, vaultEngine)
            })
        }
    }

    // Modal Sheet or Dialog for Upload Source
    if (showUploadSourceDialog) {
        AlertDialog(
            onDismissRequest = { showUploadSourceDialog = false },
            title = { Text("Private Vault Upload") },
            text = { Text("No automatic background backup is active. Select how you would like to manually upload a family photo:") },
            confirmButton = {
                Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            showUploadSourceDialog = false
                            galleryLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.PhotoLibrary, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Choose from Photo Gallery")
                    }

                    Button(
                        onClick = {
                            showUploadSourceDialog = false
                            // Pre-populated aesthetic fallback images since there is no camera hardware in cloud builders
                            val simulatedUris = listOf(
                                "https://images.unsplash.com/photo-1511895426328-dc8714191300?q=80&w=600",
                                "https://images.unsplash.com/photo-1516627145497-ae6968895b74?q=80&w=600",
                                "https://images.unsplash.com/photo-1506869640319-fe1a24fd76dc?q=80&w=600"
                            )
                            pendingPhotoUriStr = simulatedUris.random()
                            isSimulatedChoice = true
                            checkUploadQualityFlow(currentUser, vaultEngine, onPrompt = { showQualityPrompt = true }, onDirectUpload = { quality ->
                                uploadPhotoWithGPS(pendingPhotoUriStr!!, quality, vaultEngine)
                            })
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.CameraAlt, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Simulate Camera Capture")
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showUploadSourceDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // First Time Quality Chooser Prompt
    if (showQualityPrompt) {
        AlertDialog(
            onDismissRequest = { showQualityPrompt = false },
            title = { Text("Select Upload Quality") },
            text = {
                Text("On your first upload, please choose your default upload quality. You can always override this on a per-upload basis or in Settings.\n\n" +
                     "1. Smart Compressed: Saves secure storage, faster upload.\n" +
                     "2. Original Quality: Maximum high-fidelity resolution.")
            },
            confirmButton = {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton(onClick = {
                        showQualityPrompt = false
                        vaultEngine.updateUploadQualityDefault(UploadQuality.SMART_COMPRESSED)
                        pendingPhotoUriStr?.let { uploadPhotoWithGPS(it, UploadQuality.SMART_COMPRESSED, vaultEngine) }
                    }) {
                        Text("Smart Compressed")
                    }
                    TextButton(onClick = {
                        showQualityPrompt = false
                        vaultEngine.updateUploadQualityDefault(UploadQuality.ORIGINAL_QUALITY)
                        pendingPhotoUriStr?.let { uploadPhotoWithGPS(it, UploadQuality.ORIGINAL_QUALITY, vaultEngine) }
                    }) {
                        Text("Original Quality")
                    }
                }
            }
        )
    }

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showUploadSourceDialog = true },
                icon = { Icon(Icons.Default.AddAPhoto, contentDescription = "Add Photo") },
                text = { Text("Manual Upload") },
                shape = RoundedCornerShape(16.dp),
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Shared Photos",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${photosOnly.size} memories preserved",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                IconButton(onClick = { showOverrideQualityDialog = true }) {
                    Icon(
                        imageVector = Icons.Default.HighQuality,
                        contentDescription = "Upload Quality Defaults",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }

            // Quality override details
            if (showOverrideQualityDialog) {
                val currentQuality = currentUser?.defaultUploadQuality ?: UploadQuality.ASK
                AlertDialog(
                    onDismissRequest = { showOverrideQualityDialog = false },
                    title = { Text("Quality Settings") },
                    text = {
                        Column {
                            Text("Your default upload setting: ${currentQuality.name}")
                            Spacer(modifier = Modifier.height(12.dp))
                            TextButton(onClick = {
                                vaultEngine.updateUploadQualityDefault(UploadQuality.SMART_COMPRESSED)
                                showOverrideQualityDialog = false
                            }) { Text("Change to Smart Compressed") }
                            TextButton(onClick = {
                                vaultEngine.updateUploadQualityDefault(UploadQuality.ORIGINAL_QUALITY)
                                showOverrideQualityDialog = false
                            }) { Text("Change to Original Quality") }
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = { showOverrideQualityDialog = false }) { Text("Close") }
                    }
                )
            }

            if (photosOnly.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.PhotoLibrary,
                            contentDescription = null,
                            modifier = Modifier.size(64.dp),
                            tint = MaterialTheme.colorScheme.outline
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No photos in this family vault yet.",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 140.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(photosOnly, key = { it.id }) { item ->
                        PhotoCardItem(item = item, onClick = { onNavigateToDetail(item) })
                    }
                }
            }
        }
    }
}

@Composable
fun PhotoCardItem(
    item: MediaItem,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Image(
                painter = rememberAsyncImagePainter(item.uriString),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )

            // Location Badge: ONLY shown if a valid location is actually available.
            // Requirement: "If GPS/location is unavailable: Do NOT show "Location unavailable", Do NOT show empty field, etc. Simply hide completely."
            if (item.latitude != null && item.longitude != null && !item.locationName.isNullOrEmpty()) {
                Row(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp)
                        .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = "Location",
                        tint = Color.White,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                    Text(
                        text = item.locationName,
                        color = Color.White,
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.widthIn(max = 100.dp)
                    )
                }
            }

            // Quality Label
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(8.dp)
                    .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = if (item.uploadQuality == UploadQuality.SMART_COMPRESSED) "Compressed" else "HQ",
                    color = Color.White,
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }
    }
}

// Check if we need to prompt the user for quality choice
private fun checkUploadQualityFlow(
    user: FamilyUser?,
    vaultEngine: LocalVaultEngine,
    onPrompt: () -> Unit,
    onDirectUpload: (UploadQuality) -> Unit
) {
    if (user == null) return
    if (user.defaultUploadQuality == UploadQuality.ASK) {
        onPrompt()
    } else {
        onDirectUpload(user.defaultUploadQuality)
    }
}

// Upload helper with optional location attachment simulation
private fun uploadPhotoWithGPS(
    uriStr: String,
    quality: UploadQuality,
    vaultEngine: LocalVaultEngine
) {
    // Generate simulated location sometimes to demonstrate correct location hidden behaviors
    val hasLocation = (1..10).random() > 4
    if (hasLocation) {
        val simulatedLocations = listOf(
            Triple(37.7749, -122.4194, "San Francisco Park"),
            Triple(40.7128, -74.0060, "Central Park NYC"),
            Triple(48.8566, 2.3522, "Family Vacation Paris"),
            Triple(51.5074, -0.1278, "London Square")
        )
        val selected = simulatedLocations.random()
        vaultEngine.uploadMedia(
            uriString = uriStr,
            isVideo = false,
            lat = selected.first,
            lon = selected.second,
            locName = selected.third,
            quality = quality
        )
    } else {
        // No location at all (Must hide completely!)
        vaultEngine.uploadMedia(
            uriString = uriStr,
            isVideo = false,
            lat = null,
            lon = null,
            locName = null,
            quality = quality
        )
    }
}
