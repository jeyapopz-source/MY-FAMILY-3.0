package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.rememberAsyncImagePainter
import com.example.data.*
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideosTab(
    vaultEngine: LocalVaultEngine,
    onNavigateToDetail: (MediaItem) -> Unit
) {
    val context = LocalContext.current
    val mediaItems by vaultEngine.mediaItems.collectAsState()
    val currentUser by vaultEngine.currentUser.collectAsState()

    val videosOnly = remember(mediaItems) { mediaItems.filter { it.isVideo } }

    var showUploadSourceDialog by remember { mutableStateOf(false) }
    var showQualityPrompt by remember { mutableStateOf(false) }
    var pendingVideoUriStr by remember { mutableStateOf<String?>(null) }

    // Real Gallery Video Picker Contract
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val uriStr = uri.toString()
            pendingVideoUriStr = uriStr
            checkUploadQualityFlow(currentUser, vaultEngine, onPrompt = { showQualityPrompt = true }, onDirectUpload = { quality ->
                uploadVideoWithGPS(uriStr, quality, vaultEngine)
            })
        }
    }

    if (showUploadSourceDialog) {
        AlertDialog(
            onDismissRequest = { showUploadSourceDialog = false },
            title = { Text("Private Video Upload") },
            text = { Text("Private Family Video Vault. No automatic scanning or cloud backup is running. Choose your manual capture source:") },
            confirmButton = {
                Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            showUploadSourceDialog = false
                            galleryLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.VideoLibrary, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Choose from Video Gallery")
                    }

                    Button(
                        onClick = {
                            showUploadSourceDialog = false
                            // Pre-populated aesthetic fallback videos since there are no media files in the compiler sandbox
                            val simulatedVideoUris = listOf(
                                "https://www.w3schools.com/html/mov_bbb.mp4",
                                "https://www.w3schools.com/html/movie.mp4"
                            )
                            val selected = simulatedVideoUris.random()
                            pendingVideoUriStr = selected
                            checkUploadQualityFlow(currentUser, vaultEngine, onPrompt = { showQualityPrompt = true }, onDirectUpload = { quality ->
                                uploadVideoWithGPS(selected, quality, vaultEngine)
                            })
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Videocam, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Simulate Video Capture")
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showUploadSourceDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showQualityPrompt) {
        AlertDialog(
            onDismissRequest = { showQualityPrompt = false },
            title = { Text("Select Upload Quality") },
            text = {
                Text("Select default quality settings for your first family video upload:\n\n" +
                     "1. Smart Compressed: Compresses video client-side prior to sharing. Saves bandwidth.\n" +
                     "2. Original Quality: Maximum full resolution and audio.")
            },
            confirmButton = {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton(onClick = {
                        showQualityPrompt = false
                        vaultEngine.updateUploadQualityDefault(UploadQuality.SMART_COMPRESSED)
                        pendingVideoUriStr?.let { uploadVideoWithGPS(it, UploadQuality.SMART_COMPRESSED, vaultEngine) }
                    }) {
                        Text("Smart Compressed")
                    }
                    TextButton(onClick = {
                        showQualityPrompt = false
                        vaultEngine.updateUploadQualityDefault(UploadQuality.ORIGINAL_QUALITY)
                        pendingVideoUriStr?.let { uploadVideoWithGPS(it, UploadQuality.ORIGINAL_QUALITY, vaultEngine) }
                    }) {
                        Text("Original Quality")
                    }
                }
            }
        )
    }

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showUploadSourceDialog = true },
                icon = { Icon(Icons.Default.VideoCall, contentDescription = "Record Video") },
                text = { Text("Manual Upload") },
                shape = RoundedCornerShape(16.dp),
                containerColor = MaterialTheme.colorScheme.secondary,
                contentColor = MaterialTheme.colorScheme.onSecondary
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            Column(modifier = Modifier.padding(vertical = 12.dp)) {
                Text(
                    text = "Shared Videos",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${videosOnly.size} video logs secured",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (videosOnly.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Videocam,
                            contentDescription = null,
                            modifier = Modifier.size(64.dp),
                            tint = MaterialTheme.colorScheme.outline
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No videos in this family vault yet.",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 140.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(videosOnly, key = { it.id }) { item ->
                        VideoCardItem(item = item, onClick = { onNavigateToDetail(item) })
                    }
                }
            }
        }
    }
}

@Composable
fun VideoCardItem(
    item: MediaItem,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Video Thumbnail preview helper
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.8f)),
                contentAlignment = Alignment.Center
            ) {
                // In a real app we might extract a frame, for mock/simulation we show a lovely movie frame overlay
                Icon(
                    imageVector = Icons.Default.PlayCircleFilled,
                    contentDescription = "Play Video",
                    tint = Color.White.copy(alpha = 0.9f),
                    modifier = Modifier.size(54.dp)
                )
            }

            // Location Badge: ONLY shown if valid location is actually available.
            // Requirement: "If GPS/location is unavailable: Do NOT show Location unavailable, Do NOT show empty field, etc. Simply hide completely."
            if (item.latitude != null && item.longitude != null && !item.locationName.isNullOrEmpty()) {
                Row(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp)
                        .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = "Location",
                        tint = Color.White,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                    Text(
                        text = item.locationName,
                        color = Color.White,
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.widthIn(max = 100.dp)
                    )
                }
            }

            // Quality Label
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(8.dp)
                    .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = if (item.uploadQuality == UploadQuality.SMART_COMPRESSED) "Compressed" else "HQ",
                    color = Color.White,
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }
    }
}

private fun checkUploadQualityFlow(
    user: FamilyUser?,
    vaultEngine: LocalVaultEngine,
    onPrompt: () -> Unit,
    onDirectUpload: (UploadQuality) -> Unit
) {
    if (user == null) return
    if (user.defaultUploadQuality == UploadQuality.ASK) {
        onPrompt()
    } else {
        onDirectUpload(user.defaultUploadQuality)
    }
}

private fun uploadVideoWithGPS(
    uriStr: String,
    quality: UploadQuality,
    vaultEngine: LocalVaultEngine
) {
    val hasLocation = (1..10).random() > 4
    if (hasLocation) {
        val simulatedLocations = listOf(
            Triple(34.0522, -118.2437, "LA Family Outing"),
            Triple(40.7306, -73.9352, "New York Sightseeing"),
            Triple(35.6762, 139.6503, "Tokyo Family Holiday")
        )
        val selected = simulatedLocations.random()
        vaultEngine.uploadMedia(
            uriString = uriStr,
            isVideo = true,
            lat = selected.first,
            lon = selected.second,
            locName = selected.third,
            quality = quality
        )
    } else {
        // Hide location completely
        vaultEngine.uploadMedia(
            uriString = uriStr,
            isVideo = true,
            lat = null,
            lon = null,
            locName = null,
            quality = quality
        )
    }
}
