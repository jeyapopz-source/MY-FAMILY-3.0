package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import com.example.data.DeviceStatus
import com.example.data.FamilyRole
import com.example.data.FamilyUser
import com.example.data.LocalVaultEngine
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(
    vaultEngine: LocalVaultEngine,
    onLoginSuccess: () -> Unit
) {
    val context = LocalContext.current
    val users by vaultEngine.users.collectAsState()

    var isOtpFlow by remember { mutableStateOf(false) }
    var selectedRoleForOtp by remember { mutableStateOf<FamilyRole?>(null) }
    var phoneNumber by remember { mutableStateOf("") }
    var otpCode by remember { mutableStateOf("") }
    var isOtpSent by remember { mutableStateOf(false) }

    var isQrFlow by remember { mutableStateOf(false) }
    var mockQrInput by remember { mutableStateOf("") }
    var newMemberName by remember { mutableStateOf("") }

    var selectedUserToSimulate by remember { mutableStateOf<FamilyUser?>(null) }

    val gradientBrush = Brush.verticalGradient(
        colors = listOf(
            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
            MaterialTheme.colorScheme.surface
        )
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(gradientBrush)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(40.dp))

            // Application Branding
            Icon(
                imageVector = Icons.Default.FamilyRestroom,
                contentDescription = "My Family Icon",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .size(100.dp)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f), CircleShape)
                    .padding(16.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "MY FAMILY",
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 2.sp
                ),
                color = MaterialTheme.colorScheme.onSurface
            )

            Text(
                text = "Our Memories • Our Vault • Forever",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp)
            )

            Spacer(modifier = Modifier.height(40.dp))

            // Current Active Flows Panel
            if (!isOtpFlow && !isQrFlow) {
                // --- Initial Screen: Choose Login Strategy ---
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f))
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Secure Private Vault Login",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 16.dp)
                        )

                        Button(
                            onClick = {
                                isOtpFlow = true
                                isQrFlow = false
                                selectedRoleForOtp = FamilyRole.OWNER
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Icon(Icons.Default.PhoneAndroid, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Owner / Admin OTP Login")
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedButton(
                            onClick = {
                                isQrFlow = true
                                isOtpFlow = false
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Icon(Icons.Default.QrCodeScanner, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Normal Member QR Enrollment")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Developer Quick Switcher (Mandatory for high fidelity visual debugging in emulation)
                Text(
                    text = "Demo/Developer Account Switcher",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(vertical = 8.dp)
                )

                users.forEach { user ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        onClick = {
                            if (user.role == FamilyRole.OWNER || user.role == FamilyRole.ADMIN) {
                                // Direct them to OTP Flow with pre-filled phone number for ease of use
                                isOtpFlow = true
                                selectedRoleForOtp = user.role
                                phoneNumber = user.phoneNumber ?: "+1 (555) 019-2831"
                                selectedUserToSimulate = user
                            } else {
                                // Members just log in immediately (no OTP)
                                if (user.deviceStatus == DeviceStatus.REVOKED) {
                                    Toast.makeText(context, "Access Denied: This device enrollment has been revoked!", Toast.LENGTH_LONG).show()
                                } else {
                                    vaultEngine.loginAsUser(user)
                                    onLoginSuccess()
                                }
                            }
                        },
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                if (user.profilePhotoUri != null) {
                                    Image(
                                        painter = rememberAsyncImagePainter(user.profilePhotoUri),
                                        contentDescription = null,
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                } else {
                                    Icon(
                                        imageVector = if (user.role == FamilyRole.OWNER) Icons.Default.VpnKey else if (user.role == FamilyRole.ADMIN) Icons.Default.Security else Icons.Default.Person,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(16.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = user.name,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodyLarge
                                )
                                Text(
                                    text = "Role: ${user.role.name} • Status: ${user.deviceStatus.name}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (user.deviceStatus == DeviceStatus.REVOKED) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Icon(
                                imageVector = Icons.Default.ArrowForwardIos,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = MaterialTheme.colorScheme.outline
                            )
                        }
                    }
                }
            } else if (isOtpFlow) {
                // --- OTP FLOW FOR OWNER AND ADMINS ---
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = {
                                isOtpFlow = false
                                isOtpSent = false
                                selectedUserToSimulate = null
                            }) {
                                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                            }
                            Text(
                                text = "OTP Verification",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Text(
                            text = "Owners and Admins must verify using OTP. A secure code will be simulated for testing.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(vertical = 12.dp)
                        )

                        if (!isOtpSent) {
                            OutlinedTextField(
                                value = phoneNumber,
                                onValueChange = { phoneNumber = it },
                                label = { Text("Phone Number") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp)
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            Button(
                                onClick = {
                                    if (phoneNumber.trim().isEmpty()) {
                                        Toast.makeText(context, "Please enter your phone number.", Toast.LENGTH_SHORT).show()
                                    } else {
                                        isOtpSent = true
                                        Toast.makeText(context, "OTP Sent! Simulated Code is 123456", Toast.LENGTH_LONG).show()
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Send Verification Code")
                            }
                        } else {
                            Text(
                                text = "Verification code sent to $phoneNumber",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(bottom = 12.dp)
                            )

                            OutlinedTextField(
                                value = otpCode,
                                onValueChange = { otpCode = it },
                                label = { Text("6-Digit OTP Code") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp)
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            Button(
                                onClick = {
                                    if (otpCode == "123456" || otpCode.length >= 4) {
                                        // Successful login
                                        val target = selectedUserToSimulate ?: users.find { it.role == selectedRoleForOtp } ?: FamilyUser(
                                            id = "user_owner",
                                            name = "Family Owner",
                                            role = FamilyRole.OWNER,
                                            phoneNumber = phoneNumber,
                                            deviceId = UUID.randomUUID().toString()
                                        )
                                        vaultEngine.loginAsUser(target)
                                        onLoginSuccess()
                                        Toast.makeText(context, "OTP Verified! Access Granted.", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, "Invalid OTP code. Please enter '123456' for testing.", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Verify & Login")
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            TextButton(onClick = { isOtpSent = false }) {
                                Text("Resend Code")
                            }
                        }
                    }
                }
            } else if (isQrFlow) {
                // --- QR SYSTEM ENROLLMENT ---
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { isQrFlow = false }) {
                                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                            }
                            Text(
                                text = "Scan Family QR",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Text(
                            text = "To enroll as a normal Member, scan the enrollment QR generated by the Owner or Admin.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(vertical = 12.dp)
                        )

                        // UI Simulation of scanning a QR code
                        Card(
                            modifier = Modifier
                                .size(180.dp)
                                .background(Color.Black.copy(alpha = 0.05f), RoundedCornerShape(16.dp))
                                .padding(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.Transparent)
                        ) {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.QrCodeScanner,
                                    contentDescription = "Scan",
                                    modifier = Modifier.size(80.dp),
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        OutlinedTextField(
                            value = newMemberName,
                            onValueChange = { newMemberName = it },
                            label = { Text("Your Name") },
                            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = mockQrInput,
                            onValueChange = { mockQrInput = it },
                            label = { Text("Enter QR Code String / Code") },
                            placeholder = { Text("e.g. inv_xxxx") },
                            leadingIcon = { Icon(Icons.Default.Link, contentDescription = null) },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                if (newMemberName.trim().isEmpty() || mockQrInput.trim().isEmpty()) {
                                    Toast.makeText(context, "Please enter your name and QR code string.", Toast.LENGTH_SHORT).show()
                                } else {
                                    // Parse the QR link or code
                                    val code = mockQrInput.substringAfter("id=").substringBefore("&")
                                    val success = vaultEngine.claimQRInvitation(
                                        inviteId = code,
                                        newMemberName = newMemberName,
                                        newDeviceId = "device_" + UUID.randomUUID().toString().take(6)
                                    )
                                    if (success) {
                                        Toast.makeText(context, "QR Enrollment Successful!", Toast.LENGTH_SHORT).show()
                                        // Login as the newly created user
                                        val newlyCreatedUser = vaultEngine.users.value.lastOrNull()
                                        if (newlyCreatedUser != null) {
                                            vaultEngine.loginAsUser(newlyCreatedUser)
                                            onLoginSuccess()
                                        }
                                    } else {
                                        Toast.makeText(context, "Invalid, expired, or revoked QR code.", Toast.LENGTH_LONG).show()
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Enroll & Start Sharing")
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "Demo Tip: Owner/Admins generate QR codes from the 'Family' Tab. Copy the code from there and paste it here to simulate!",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.outline,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}
