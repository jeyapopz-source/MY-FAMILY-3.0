package com.example.data

import android.net.Uri

enum class FamilyRole {
    OWNER,
    ADMIN,
    MEMBER
}

enum class DeviceStatus {
    ACTIVE,
    REVOKED,
    PENDING
}

enum class UploadQuality {
    ASK,
    SMART_COMPRESSED,
    ORIGINAL_QUALITY
}

data class FamilyUser(
    val id: String,
    val name: String,
    val role: FamilyRole,
    val profilePhotoUri: String? = null,
    val deviceId: String? = null,
    val deviceStatus: DeviceStatus = DeviceStatus.ACTIVE,
    val phoneNumber: String? = null,
    val defaultUploadQuality: UploadQuality = UploadQuality.ASK
)

data class MediaItem(
    val id: String,
    val uriString: String,
    val isVideo: Boolean,
    val timestamp: Long,
    val uploaderId: String,
    val uploaderName: String,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val locationName: String? = null,
    val uploadQuality: UploadQuality = UploadQuality.SMART_COMPRESSED
)

data class Moment(
    val id: String,
    val text: String,
    val timestamp: Long,
    val uploaderId: String,
    val uploaderName: String
)

data class QRInvitation(
    val id: String,
    val role: FamilyRole,
    val generatedBy: String,
    val timestamp: Long,
    val isRevoked: Boolean = false,
    val usedBy: String? = null
)

data class FamilyConfig(
    val familyName: String = "Our Family",
    val coverPhotoUri: String? = null
)

data class AppNotification(
    val id: String,
    val title: String,
    val message: String,
    val timestamp: Long,
    val isRead: Boolean = false
)
